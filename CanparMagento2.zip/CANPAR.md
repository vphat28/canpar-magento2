INSTALLATION
- Make sure you set your pick up address in 

CHANGELOGS
1.0.1 
- Update api endpoints 
- Fix some issues in configuration system
