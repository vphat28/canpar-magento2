<?php
namespace CollinsHarper\Canpar\Logger;

class Logger extends \Monolog\Logger
{
}
